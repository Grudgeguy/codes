#include<string.h>
#include<stdio.h>
int main(){
    float a=3.6754;
    // scanf("%s",s1);
    // scanf("%s",s2);
    printf("%0.1f",a);
}