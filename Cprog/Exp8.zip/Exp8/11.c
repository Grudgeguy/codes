#include<string.h>
#include<stdio.h>
int main(){
    char s[50],s1[50];
    scanf("%s",s);
    char *p1=s,*p2=s1;
    for(int i=0;i<strlen(s);i++){
        *(p2+i)=*(p1+i);
    }
    for(int i=0;i<strlen(s1)-2;i++){
        printf("%c",s1[i]);
    }
}