
        i++;
    }
    printf("The size of the string is %d",i);
}